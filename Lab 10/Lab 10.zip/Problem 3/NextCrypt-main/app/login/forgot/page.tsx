export default function Forgot() {
    return (<>Forgot Password</>);
}