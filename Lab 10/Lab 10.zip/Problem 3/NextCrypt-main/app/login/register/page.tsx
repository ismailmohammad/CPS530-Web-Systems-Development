export default function Forgot() {
    return (<>Register</>);
}